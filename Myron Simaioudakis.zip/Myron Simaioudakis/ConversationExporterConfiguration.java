//Myron Simaioudakis
package javaapplication2;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents the configuration for the exporter.
 */
public final class ConversationExporterConfiguration {
    /**
     * Gets the input file path.
     */
    public String inputFilePath;

    /**
     * Gets the output file path.
     */
    public String outputFilePath;
    /**
     * Gets the output file path.
     */
    public String[] userFilter;

    /**
     * Initializes a new instance of the {@link ConversationExporterConfiguration} class.
     * @param inputFilePath The input file path.
     * @param outputFilePath The output file path.
     * @param UserFilter Filter by user.
     */
    public ConversationExporterConfiguration(String inputFilePath, String outputFilePath) {
        this.userFilter = null;
        this.inputFilePath = inputFilePath;
        this.outputFilePath = outputFilePath;
    }
    
    public ConversationExporterConfiguration(String[] arguments) {
        this.inputFilePath = arguments[0];
        this.outputFilePath = arguments[1];
        this.userFilter = new String[arguments.length-2];
        for(int i= 2; i< arguments.length; ++i){
            userFilter[i-2] = arguments[i];
        }
    }
}
