//Myron Simaioudakis
package javaapplication2;

import com.google.gson.*;
import java.io.*;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Represents the optional questions. Hide Card and Phone numbers. Indicates the activity
 */
public class OptionalQuestions {

    /**
     * A helper method to hide the Card and Phone numbers.
     * @param exporter Essential in order to write to the JSON output.
     * @param configuration Essential as it was initialised at the main.
     * @param args Essential as it was initialised at the main.
     * @throws Exception Thrown when something bad happens.
     */
    public void FilterCardPhoneNumbers(ConversationExporter exporter, ConversationExporterConfiguration configuration, String[] args ) throws Exception {
        
        Conversation conversation = this.FilterNumbersActivity(configuration.inputFilePath);
        
        exporter.writeConversation(conversation, configuration.outputFilePath);
        System.out.println("Conversation changed from '" + configuration.inputFilePath + "' to '" + configuration.outputFilePath);
    }
    
    
    /**
     * The key method to hide and check the activity.
     * @param inputFilePath The path to the input file.
     * @return The {@link Conversation} representing by the input file.
     * @throws Exception Thrown when something bad happens.
     */
    public Conversation FilterNumbersActivity(String inputFilePath) throws Exception {
        //starts reading the file line by line
        try(InputStream is = new FileInputStream(inputFilePath);
            BufferedReader r = new BufferedReader(new InputStreamReader(is))) {
            
            //Create arraylist of messages obs.
            List<Message> messages = new ArrayList<Message>();

            String conversationName = r.readLine();
            String line;
            HashMap<String, Integer> mymap = new HashMap<String, Integer>();
            //every new line is a new message
            while ((line = r.readLine()) != null) {
                String[] split = line.split(" ");
                Long str0 = Long.parseUnsignedLong(split[0]);
                String str1 = split[1];
                String str2 = "";
                String user = str1;
                if(mymap.containsKey(user)){
                    int value = mymap.get(user) + 1;
                    mymap.put(user, value);
                }
                else{
                    mymap.put(user,1);
                }
                for(int i=2; i<split.length;++i){
                    if(isCardorPhone(split[i]))
                        str2 = str2 + "*redacted* ";
                    else
                        str2 = str2 + split[i] +" ";
                }
                messages.add(new Message(Instant.ofEpochSecond(str0), str1, str2));
            }
            String mylist = "The activity of the users:";
            Iterator nit = mymap.entrySet().iterator();
            while(nit.hasNext()){
                int max = -1;
                for(int value : mymap.values()){
                    if(value > max){
                        max = value;
                    }
                }
                Iterator it = mymap.entrySet().iterator();
                while(it.hasNext()){
                    Map.Entry pair = (Map.Entry)it.next();
                    if( (int) pair.getValue() == max){
                        mylist = mylist + pair.getKey() + " "+ pair.getValue() + ' ';
                        it.remove();
                    }
                }
                nit = mymap.entrySet().iterator();
            }               
            messages.add(new Message(null, null, mylist));
            return new Conversation(conversationName, messages);
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("The file was not found.");
        } catch (IOException e) {
            throw new Exception("Something went wrong");
        }
    }
        
   /**
    * Helper to check if a string is a Phone or Card number.
    * @param str The string we want to check.
    * @return A boolean according to the sting.
    * @throws Exception Thrown when something bad happens.
    */ 
    private boolean isCardorPhone(String str){
    //  Phone format xxx-xxx-xxxx
        String Pformat = "^[0-9]{3}\\-?[0-9]{3}\\-?[0-9]{4}$" ;
    //  Card format xxxx-xxxx-xxxx-xxxx
        String Cformat = "^[0-9]{4}\\-?[0-9]{4}\\-?[0-9]{4}-?[0-9]{4}$" ; 

        if(str.matches(Pformat) || str.matches(Cformat))
            return true;
        else
            return false;
    }
}    

