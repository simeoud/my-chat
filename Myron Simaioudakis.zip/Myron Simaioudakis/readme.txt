The code was implemented and checked using Netbeans 8.1
The only JARs that were used were: junit-4.12 and gson-2.5.