//Myron Simaioudakis
package javaapplication2;

import com.google.gson.*;

import java.io.*;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Represents a conversation exporter that can read a conversation and write it out in JSON.
 */
public class ConversationExporter {

    /**
     * The application entry point.
     * @param args The command line arguments.
     * @throws Exception Thrown when something bad happens.
     */
    public static void main(String[] args) throws Exception {
        ConversationExporter exporter = new ConversationExporter();
        ConversationExporterConfiguration configuration = new CommandLineArgumentParser().parseCommandLineArguments(args);
//        Uncomment every time the question that you want.
//        Question 1  Use only two arguments         
//        exporter.exportConversation(configuration.inputFilePath, configuration.outputFilePath);

        if(configuration.userFilter != null){
//          Question 2 Use only three arguments  
//            exporter.FilterConversationByUserorWord(configuration.inputFilePath, configuration.outputFilePath, configuration.userFilter[0], "user");

//          Question 3 Use only three arguments  
//            exporter.FilterConversationByUserorWord(configuration.inputFilePath, configuration.outputFilePath, configuration.userFilter[0], "word");
            
//          Question 4 Use three or more arguments 
//            exporter.HideWords(configuration.inputFilePath, configuration.outputFilePath, configuration.userFilter);
        }
        else{
            System.out.println("Please insert more elements in the command line!");
        }
        
//        Question 5 and 7
//            OptionalQuestions FilterCardsPhones = new OptionalQuestions();
//            FilterCardsPhones.FilterCardPhoneNumbers(exporter, configuration, args);
    }

    /**
     * Exports the conversation at {@code inputFilePath} as JSON to {@code outputFilePath}.
     * @param inputFilePath The input file path.
     * @param outputFilePath The output file path.
     * @throws Exception Thrown when something bad happens.
     */
    public void exportConversation(String inputFilePath, String outputFilePath) throws Exception {
        //Has the name of the convesation and an arralist of the messages
        Conversation conversation = this.readConversation(inputFilePath);

//        Conversation conversation = this.FilterConversation(inputFilePath, outputFilePath);
        
        this.writeConversation(conversation, outputFilePath);

        System.out.println("Conversation exported from '" + inputFilePath + "' to '" + outputFilePath);
    }


    /**
     * Represents a helper to read a conversation from the given {@code inputFilePath}.
     * @param inputFilePath The path to the input file.
     * @return The {@link Conversation} representing by the input file.
     * @throws Exception Thrown when something bad happens.
     */
    public Conversation readConversation(String inputFilePath) throws Exception {
        //starts reading the file line by line
        try(InputStream is = new FileInputStream(inputFilePath);
            BufferedReader r = new BufferedReader(new InputStreamReader(is))) {
            
            //Create arraylist of messages obs.
            List<Message> messages = new ArrayList<Message>();

            String conversationName = r.readLine();
            String line;
            
            //every new line is a new message
            while ((line = r.readLine()) != null) {
                String[] split = line.split(" ");
                Long str0 = Long.parseUnsignedLong(split[0]);
                String str1 = split[1];
                String str2 = split[2];
                messages.add(new Message(Instant.ofEpochSecond(str0), str1, str2));

            }
            return new Conversation(conversationName, messages);
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("The file was not found.");
        } catch (IOException e) {
            throw new Exception("Something went wrong");
        }
    }

    
    /**
     * Represents a helper to filter a conversation by username or word {@code inputFilePath}.
     * @param inputFilePath The input file path.
     * @param outputFilePath The output file path.
     * @param userfilter The word that the user filters.
     * @param type Is it user or keyword?
     * @throws Exception Thrown when something bad happens.
     */
    public void FilterConversationByUserorWord(String inputFilePath, String outputFilePath, String userfilter, String type) throws Exception {
        //Has the name of the convesation and an arralist of the messages
        Conversation conversation = this.FilterConversation(inputFilePath,userfilter,type);

        this.writeConversation(conversation, outputFilePath);

        System.out.println("Conversation filtered from '" + inputFilePath + "' to '" + outputFilePath);
    }
    
    
    /**
     * Represents the filter of the convesation of the username or word from the given {@code inputFilePath}.
     * @param inputFilePath The path to the input file.
     * @param userfilter The word that the user filters.
     * @param type Is it user or keyword?
     * @return The {@link Conversation} representing by the input file.
     * @throws Exception Thrown when something bad happens.
     */
    public Conversation FilterConversation(String inputFilePath, String userfilter, String type) throws Exception {
        //starts reading the file line by line
        try(InputStream is = new FileInputStream(inputFilePath);
            BufferedReader r = new BufferedReader(new InputStreamReader(is))) {
            
            //Create arraylist of messages obs.
            List<Message> messages = new ArrayList<Message>();

            String conversationName = r.readLine();
            String line;
            
            //every new line is a new message
            while ((line = r.readLine()) != null) {
                String[] split = line.split(" ");
                Long str0 = Long.parseUnsignedLong(split[0]);
                String str1 = split[1];
                String str2 = "";
                if(type.equals("user")){
                    if(str1.equals(userfilter)){
                        for (int i=2; i<split.length;++i){
                            str2 = str2 + split[i]+ " ";
                        }
                        messages.add(new Message(Instant.ofEpochSecond(str0), str1, str2));
                    }  
                }
                else{
                    boolean flag = false;
                    for (int i=2; i<split.length;++i){
                        str2 = str2 + split[i]+ " ";
                        if(split[i].equals(userfilter)){
                            flag = true;
                        }
                    }
                    if(flag){
                        messages.add(new Message(Instant.ofEpochSecond(str0), str1, str2));
                    }
                }
            }
            return new Conversation(conversationName, messages);
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("The file was not found.");
        } catch (IOException e) {
            throw new Exception("Something went wrong");
        }
    }
    
    
    /**
     * Represents a helper to hilde a blacklist of words from the {@code inputFilePath}.
     * @param inputFilePath The input file path.
     * @param outputFilePath The output file path.
     * @param hideword The word we want to hide.
     * @throws Exception Thrown when something bad happens.
     */
    public void HideWords(String inputFilePath, String outputFilePath, String [] hideword) throws Exception {
        //Has the name of the convesation and an arralist of the messages
        Conversation conversation = this.HidenWords(inputFilePath, hideword);

        this.writeConversation(conversation, outputFilePath);

        System.out.println("Conversation hiden from '" + inputFilePath + "' to '" + outputFilePath);
    }
 
    
    /**
     * The words are hiding..
     * @param inputFilePath The path to the input file.
     * @param hideword The words we want to hide.
     * @return The {@link Conversation} representing by the input file.
     * @throws Exception Thrown when something bad happens.
     */
    public Conversation HidenWords(String inputFilePath, String [] hideword) throws Exception {
        //starts reading the file line by line
        try(InputStream is = new FileInputStream(inputFilePath);
            BufferedReader r = new BufferedReader(new InputStreamReader(is))) {
            
            //Create arraylist of messages obs.
            List<Message> messages = new ArrayList<Message>();

            String conversationName = r.readLine();
            String line;
            
            //every new line is a new message
            while ((line = r.readLine()) != null) {
                String[] split = line.split(" ");
                Long str0 = Long.parseUnsignedLong(split[0]);
                String str1 = split[1];
                String str2 = "";
                for (int i=2; i<split.length;++i){
                    boolean flag = false;
                    for(int j=0; j<hideword.length; ++j){
                        if(split[i].equals(hideword[j])){
                            flag = true;
                            break;
                        }
                    }
                    if(flag)
                        str2 = str2 + "*redacted* ";
                    else{
                        str2 = str2 + split[i] + " ";
                    }
                        
                }
            
                messages.add(new Message(Instant.ofEpochSecond(str0), str1, str2));
            }
            return new Conversation(conversationName, messages);
                
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("The file was not found.");
        } catch (IOException e) {
            throw new Exception("Something went wrong");
        }
    }
    
    /**
    * Helper method to write the given {@code conversation} as JSON to the given {@code outputFilePath}.
    * @param conversation The conversation to write.
    * @param outputFilePath The file path where the conversation should be written.
    * @throws Exception Thrown when something bad happens.
    */
    public void writeConversation(Conversation conversation, String outputFilePath) throws Exception {
        try (OutputStream os = new FileOutputStream(outputFilePath, true);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os))) {
            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeAdapter(Instant.class, new InstantSerializer());
            Gson g = gsonBuilder.create();          
            bw.write(g.toJson(conversation).replace('[', '\n').replace('}', '\n').replace(",{"," ").replace(",\"", " \"").replace('{', ' ').replace(']',' ').replace("\"content\":\"The activity ", "\"Messages "));
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("The file was not found.");
        } catch (IOException e) {
            throw new Exception("Something went wrong");
        }
    }
    
    class InstantSerializer implements JsonSerializer<Instant> {
        @Override
        public JsonElement serialize(Instant instant, Type type, JsonSerializationContext jsonSerializationContext) {
            return new JsonPrimitive(instant.getEpochSecond());
        }
    }
}
